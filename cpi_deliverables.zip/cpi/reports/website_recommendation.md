# Website recommendation — design and functionality

*Recommendation only. Nothing has been built or published.*

## What the site should do

The partner's advice was to build something small that produces **three defensible conclusions**, and to let the reader see how a ranking changes when the assumptions change rather than presenting one "objective" order. This analysis supports that directly:

1. **Open strategy questions sit with regional and network owners.** Water boards, grid and heat-network companies, RET and Schiphol are consulting the market on how to contract and phase work. Rijkswaterstaat work is mostly in delivery and goes through an existing advisory framework.
2. **Renewing assets that stay in use shows up as contract change.** 2026 modification notices (Oosterscheldekering, Krammer locks, A16, TenneT EU-302) are a public, repeatable signal of delivery pressure.
3. **Grid constraints show up as supply-chain strain, not as a congestion map.** None of the 45 grid-material projects can be located precisely enough for a congestion join. Framework increases and programme ramp-ups show a contractor-capacity problem.

Working title: **"Where advice fits: a screen of Dutch infrastructure procurement, 2026"**. Present it as a screening tool for further investigation, never as a list of confirmed opportunities.

## Recommended scope

Two options, both using the data already built:

| Option | What it is | For | Against |
|---|---|---|---|
| **A. National screen with a Zuid-Holland lens (recommended)** | All 183 procedures, opening on Zuid-Holland: 53 procedures and 7 of the 18 shortlist entries (Verkeersbrug Dordrecht, Drechttunnel, Van Brienenoordbrug, A16, RET, Vergulde Hand, Stedin). | Keeps the national findings; the Rijnmond–Drechtsteden lens gives the partner's suggested focus and the strongest link to the team's disclosed Rijkswaterstaat work. | Not the bridge-condition analysis the partner sketched. |
| B. Merge with "Bridges Under Pressure" | Add RWS asset GIS layers for Rotterdam bridges and use this procurement data as the delivery-pipeline layer. | Closest to the partner's preferred concept. | Needs new data collection and validation; the asset layers do not show condition (DISK access is restricted). |

Option A can be built from what exists. Option B is a reasonable second version.

## Pages and features

**1. Overview.** The question, the three findings (one chart each), a one-paragraph method and the caveats. Snapshot date shown prominently (data to 14 Oct 2026).

**2. Shortlist explorer.**
- Ranked table of the 154 projects/clusters, 18 highlighted.
- **Scenario controls:** four capability-weight sliders plus timing and confidence strength, with presets for the seven tested scenarios. Ranks recompute in the browser with the same formula as `scripts/03_score.py`.
- Rank-change arrows against the baseline and a **stability badge** (top 18 in x of 7 scenarios).
- Filters: sector stratum, status, province, authority type, capability.

**3. Map.**
- Province and NUTS3 boundaries (public CBS/PDOK geometry).
- **Location precision shown, not hidden:** NUTS3-located projects at region level, province-coded projects as province outlines, national-only projects in a side list. No point markers suggesting site-level precision.
- No value-sized bubbles: values are missing for most projects.

**4. Project evidence page** (one per shortlist entry, generated from `data/shortlist.csv` and `data/master_dataset.csv`).
- Notice timeline (prior information → contract notice → award → modification) with TenderNed links.
- Four capability scores, **rule score and reviewed score side by side**, with the review rationale and matched evidence.
- PDF-validated fields with check marks; values and winners where the PDF gives them.
- Advisory status, evidence gaps and follow-up, as in the shortlist report.

**5. Delivery signals.** Modification tracker; grid-materiality breakdown with a plain explanation of why congestion could not be linked and what would make it possible.

**6. Method and data.** The Phase 5 report, validation tables, downloadable CSVs and a link to the scripts.

## Design principles

- Show uncertainty next to every number: confidence score, stability badge, "not stated" for missing values.
- Never mix exposure into the priority score; show it beside it.
- Name sources on every claim. Mentions of PwC's existing work use only public announcements, attributed.
- English interface, with Dutch procurement terms (bouwteam, marktconsultatie, vernieuwingsopgave) kept and glossed.
- Mobile-friendly; static and fast.

## Technical approach

- **Data:** Python exports `master_dataset.csv`, `shortlist.csv`, `sensitivity.csv` and `validation_results.csv` to static JSON. No live API calls from the site.
- **Front end:** Vite with a light framework (Svelte or React), MapLibre GL for the map, a small chart library for the three findings.
- **Parity test:** a test that the browser scoring reproduces the Python priority for all 183 procedures under each preset.
- **Hosting:** any static host (GitHub Pages, as the partner suggested), or a private Claude artifact for review before anything is public. Publishing is your decision.

## What to leave out

- A single headline "opportunity score" without the scenario controls.
- Any grid-congestion layer until the capacity data is actually joined.
- Market-share or spend totals: the sample is not a census and values are incomplete.
- Claims about which projects PwC is or is not working on beyond the cited public sources.

## Decisions for you before building

1. **Scope:** option A (national screen, Zuid-Holland lens) or B (merge with the bridges concept).
2. **Version 2 data:** whether to allow the TenderNed bulk archive and the Netbeheer capacity map in the workspace's network settings, which would make the sample a census and the grid test runnable.
3. **PwC framing:** whether a public site should reference PwC's disclosed Rijkswaterstaat roles at all, or keep the analysis client-neutral and make that link in your message to the team.
