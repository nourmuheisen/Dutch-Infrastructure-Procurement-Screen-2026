# CP&I relevance screen — Dutch infrastructure procurement 2026

A reproducible screen of 2026 TenderNed notices for projects where Capital Projects & Infrastructure advisory capabilities are most relevant. Data to 14 Oct 2026.

## Read first
| File | Content |
|---|---|
| `reports/phase4_shortlist.md` | Ranked 18-project shortlist, three findings, robustness, watch-list, evidence per entry |
| `reports/phase5_methodology_validation.md` | Collection, cleaning, scoring, AI use, validation results, limitations, improvements |
| `reports/website_recommendation.md` | Proposed site design and functionality (not built) |

## Supporting reports
`reports/phase1_collection_log.md` (sources and coverage) · `reports/phase2_scoring_model.md` (rubrics and formula) · `reports/phase3_constraints.md` (grid data and delivery exposure)

## Datasets (`data/`)
| File | Rows | Content |
|---|---|---|
| `notices_all.csv` | 411 | Every unique notice collected |
| `screening_log.csv` | 287 | In/out-of-scope decision per procedure with the triggering term |
| `phase1_projects.csv` | 183 | In-scope procedures: authority, location, status, dates, CPV, NUTS, source URL |
| `master_dataset.csv` | 183 | Phase 1 + rule and reviewed capability scores, evidence, confidence, timing, priority, exposure, cluster |
| `review_adjustments.csv` | ~150 | Every reviewer change to a rule score, with rationale |
| `clusters.csv` | 154 | Projects/programme clusters ranked |
| `sensitivity.csv` | 154 | Rank under seven weighting scenarios |
| `shortlist.csv` | 18 | Annotated shortlist |
| `validation_pdf_extracts.csv`, `validation_results.csv`, `validation_summary.json` | 26 | PDF validation |

## Website
`site/where-advice-fits.html` — standalone page (open in any browser; data and fonts are inside the file). Built from `site/src.html` and `site/data.json` by `scripts/10_export_site.py` and `scripts/11_build_site.py`. Fonts: Barlow, Barlow Condensed, IBM Plex Mono (SIL Open Font License). Map: CBS/PDOK 2025 COROP and province boundaries with Eurostat NUTS 2024 ids.

## Rerun
Scripts in `scripts/` run in order 01 → 11 (see the Phase 5 report). Weights: `scripts/scoring_config.json`.
